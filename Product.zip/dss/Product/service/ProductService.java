package com.product.service;

import java.util.Date;
import java.util.List;

import com.ctc.ctfs.dss.account.domain.Account;
import com.ctc.ctfs.dss.account.domain.CardActivationData;
import com.ctc.ctfs.dss.account.domain.ForceToQueue;
import com.ctc.ctfs.dss.account.domain.PANLockoutOutput;
import com.ctc.ctfs.dss.account.domain.PromiseToPayData;
import com.ctc.ctfs.dss.account.domain.RegisteredCardState;
import com.ctc.ctfs.dss.account.domain.UpdateCDFValue;
import com.ctc.ctfs.dss.account.exception.CVCVerificationException;
import com.ctc.ctfs.dss.account.exception.MaxCVCAttemptsException;
import com.ctc.ctfs.dss.account.model.AddPTPInput;
import com.ctc.ctfs.dss.account.model.AddTsysNoteInput;
import com.ctc.ctfs.dss.account.model.CancelPromiseToPayInput;
import com.ctc.ctfs.dss.account.model.GraceDueDateRequest;
import com.ctc.ctfs.dss.account.model.GraceDueDateResponse;
import com.ctc.ctfs.dss.account.model.ReissueStatusOutput;
import com.ctc.ctfs.dss.account.model.UpdateAccountStatusInput;
import com.ctc.ctfs.dss.coll.domain.ProvinceHoliday;

public interface ProductService {
	
	public Account findAccountByCardNbr(String operatorId, String cardNbr,boolean bypassCache) throws Exception;
	
}
