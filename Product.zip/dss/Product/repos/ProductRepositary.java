package com.product.repos;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.ctc.ctfs.dss.account.domain.CVCAttempt;

public interface ProductRepositary extends CrudRepository<Product,Long> {
	//CRUD operation
	

}
