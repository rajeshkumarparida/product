package com.ctc.ctfs.dss.account;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ctc.ctfs.dss.account.domain.Account;
import com.ctc.ctfs.dss.account.domain.AccountInput;
import com.ctc.ctfs.dss.account.domain.Address;
import com.ctc.ctfs.dss.account.domain.CardActivationData;
import com.ctc.ctfs.dss.account.domain.Customer;
import com.ctc.ctfs.dss.account.domain.CustomerAccount;
import com.ctc.ctfs.dss.account.domain.CustomerEmailDates;
import com.ctc.ctfs.dss.account.domain.CustomerForUpdate;
import com.ctc.ctfs.dss.account.domain.CustomerId;
import com.ctc.ctfs.dss.account.domain.EmailProfile;
import com.ctc.ctfs.dss.account.domain.EmployerData;
import com.ctc.ctfs.dss.account.domain.EmploymentInfo;
import com.ctc.ctfs.dss.account.domain.ForceToQueue;
import com.ctc.ctfs.dss.account.domain.IssueCardRequest;
import com.ctc.ctfs.dss.account.domain.Location;
import com.ctc.ctfs.dss.account.domain.MarketingOption;
import com.ctc.ctfs.dss.account.domain.PANLockoutOutput;
import com.ctc.ctfs.dss.account.domain.PhoneType;
import com.ctc.ctfs.dss.account.domain.PrimaryCardholder;
import com.ctc.ctfs.dss.account.domain.PromiseToPayData;
import com.ctc.ctfs.dss.account.domain.RegisteredCardState;
import com.ctc.ctfs.dss.account.domain.TelephoneNumber;
import com.ctc.ctfs.dss.account.domain.UpdateCDFValue;
import com.ctc.ctfs.dss.account.exception.AccountNotFoundException;
import com.ctc.ctfs.dss.account.exception.CVCVerificationException;
import com.ctc.ctfs.dss.account.exception.MaxCVCAttemptsException;
import com.ctc.ctfs.dss.account.model.AccountStateInput;
import com.ctc.ctfs.dss.account.model.AccountStateOutput;
import com.ctc.ctfs.dss.account.model.ActivateCardInput;
import com.ctc.ctfs.dss.account.model.ActivateCardOuput;
import com.ctc.ctfs.dss.account.model.AddPTPInput;
import com.ctc.ctfs.dss.account.model.AddTsysNoteInput;
import com.ctc.ctfs.dss.account.model.CPInsuranceBeanRequest;
import com.ctc.ctfs.dss.account.model.CancelPromiseToPayInput;
import com.ctc.ctfs.dss.account.model.CorrespondenceInput;
import com.ctc.ctfs.dss.account.model.CustomerAccountInput;
import com.ctc.ctfs.dss.account.model.CustomerAddressRequest;
import com.ctc.ctfs.dss.account.model.CustomerAddressResponse;
import com.ctc.ctfs.dss.account.model.CustomerEmailInput;
import com.ctc.ctfs.dss.account.model.EPaymentTransaction;
import com.ctc.ctfs.dss.account.model.EmailProfileInput;
import com.ctc.ctfs.dss.account.model.EmailUpdateInput;
import com.ctc.ctfs.dss.account.model.EmploymentInfoInput;
import com.ctc.ctfs.dss.account.model.EstatementEnrollInput;
import com.ctc.ctfs.dss.account.model.EstatementInput;
import com.ctc.ctfs.dss.account.model.GraceDueDateRequest;
import com.ctc.ctfs.dss.account.model.GraceDueDateResponse;
import com.ctc.ctfs.dss.account.model.PaymentInput;
import com.ctc.ctfs.dss.account.model.ReissueStatusOutput;
import com.ctc.ctfs.dss.account.model.StatementProfileOutput;
import com.ctc.ctfs.dss.account.model.UpdateAccountStatusInput;
import com.ctc.ctfs.dss.account.model.UpdateStatementProfileInput;
import com.ctc.ctfs.dss.account.service.AccountService;
import com.ctc.ctfs.dss.account.service.CardholderService;
import com.ctc.ctfs.dss.account.service.CustomerService;
import com.ctc.ctfs.dss.account.service.CustomerUpdateService;
import com.ctc.ctfs.dss.account.service.InsuranceService;
import com.ctc.ctfs.dss.account.service.PaymentService;
import com.ctc.ctfs.dss.coll.domain.ProvinceHoliday;

@RestController
@RequestMapping("${spring.application.version}")
public class ProductController
{
    private static final transient Logger LOG = LoggerFactory.getLogger(AccountController.class);
    private AccountService accountService;
    private PaymentService paymentService;
    
    //Mappings Moved from Customer Service To Account Service: Begin
    private static final String VENDOR_CTFS		= "CTFS";
	private static final String VENDOR_EPOST	= "EPOST";
	private static final String CONST_EPOST_DEENROLLMENT_ESTMT_ENROL_CORRESPONDENCE_ID	= "ESPEST";	
	private static final String CONST_EPOST_DEENROLLMENT_CORRESPONDENCE_ID	= "ESPHCS";
	private static final String CONST_ESTATEMENT_DEENROLLMENT_CORRESPONDENCE_ID	= "ESTHCS";
	private static final String CONST_CORRESPONDENCE_LETTER_TYPE  = "Letter";
	
	@Autowired
	private CustomerUpdateService customerUpdateService;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private CardholderService cardholderService;
	
	@Autowired
	private InsuranceService insuranceService;
    //Mappings Moved from Customer Service To Account Service: End

    @Autowired
    public ProductController(AccountService accountService,PaymentService paymentService)
    {
        this.accountService = accountService;
        this.paymentService = paymentService;
    }

    @RequestMapping (value = "/getAccount", method = RequestMethod.POST)
    public Account getAccount(@Valid @RequestBody AccountInput input, @RequestHeader(value="byPassCache")  boolean byPassCache ) throws Exception
    {

        LOG.debug("getAccount() entry");
        Account account = accountService.findAccountByCardNbr("servic", input.getCardNbr(),byPassCache);
        if (account == null)
            throw new AccountNotFoundException(input.getCardNbr());

        LOG.debug("getAccount() exit");
        return account;
    }
    
    @RequestMapping (value = "/getCurrentAccount", method = RequestMethod.POST)
    public Account getCurrentAccount(@Valid @RequestBody AccountInput input, @RequestHeader(value="byPassCache")  boolean byPassCache ) throws Exception
    {

        LOG.debug("getAccount() entry");
        Account account = accountService.findCurrentAccount(input.getOperatorId(), input.getCardNbr(),byPassCache);
        if (account == null)
            throw new AccountNotFoundException(input.getCardNbr());

        LOG.debug("getAccount() exit");
        return account;
    }

    @RequestMapping(value = "/getCardActivation", method = RequestMethod.POST)
    public CardActivationData getCardActivation(@Valid @RequestBody AccountInput input) throws Exception
    {

        LOG.debug("getCardActivation() entry");
        CardActivationData activationData = accountService.findCardActivationDataByCardNbr(input.getOperatorId(), input.getCardNbr());
        if (activationData == null)
            throw new AccountNotFoundException(input.getCardNbr());

        LOG.debug("getCardActivation() exit");
        return activationData;
    }
    

    @RequestMapping(value = "/verifycvc", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void verifyCVC(@Valid @RequestBody AccountInput input) throws CVCVerificationException,MaxCVCAttemptsException, Exception
    {
        LOG.debug("verifyCVC() entry");
        accountService.verifyCVC("servic", input.getCardNbr(), input.getCvc());
        LOG.debug("verifyCVC() exit");
        return;
    }

    @RequestMapping(value = "/checkPANLockout", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public PANLockoutOutput checkPANLockout(@Valid @RequestBody AccountInput input) throws MaxCVCAttemptsException, Exception
    {
        LOG.debug("checkPANLockout() entry");
        PANLockoutOutput panLockout = accountService.checkPANLockout(input.getCardNbr());
        LOG.debug("checkPANLockout() exit");
        return panLockout;
    }
    
    @RequestMapping(value = "/resetCVCLockout", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void resetCVCLockout(@Valid @RequestBody AccountInput input) throws Exception
    {
        LOG.debug("resetCVCLockout() entry");
        accountService.resetCVCLockout(input.getCardNbr());
        LOG.debug("resetCVCLockout() exit");
    }

    @RequestMapping(value = "/updateAccountStatus", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void updateAccountStatus(@RequestBody UpdateAccountStatusInput input) throws Exception{
        LOG.debug("#### AccountController.updateAccountStatus(): Begin");
        accountService.updateAccountStatus(input);
        accountService.removeAccountFromCache(input.getAccountNumber());
        LOG.debug("#### AccountController.updateAccountStatus(): End");        
    }
    
    @RequestMapping(value = "/clearAccountFromCache", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void clearAccountFromCache(@Valid @RequestBody AccountInput input) throws Exception{
        LOG.debug("#### AccountController.clearAccountFromCache(): Begin");
        accountService.removeAccountFromCache(input.getCardNbr());
        LOG.debug("#### AccountController.clearAccountFromCache(): End");        
    }
    
    @RequestMapping(value = "/addTsysNote", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void addTsysNote(@RequestBody AddTsysNoteInput input) throws Exception{
        LOG.debug("#### AccountController.addTsysNote(): Begin");
        accountService.addTsysNote(input);
        LOG.debug("#### AccountController.addTsysNote(): End");        
    }
    
    @RequestMapping(value = "/createPaymentPromise", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void createPaymentPromise(@RequestBody AddPTPInput input) throws Exception{
        LOG.debug("#### AccountController.createPaymentPromise(): Begin");
        accountService.addPTP(input);
        LOG.debug("#### AccountController.createPaymentPromise(): End");        
    }
    
    @RequestMapping(value = "/retrievePaymentPromises", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public PromiseToPayData retrievePaymentPromises(@Valid @RequestBody AccountInput input) throws Exception 
    {
        LOG.debug("#### AccountController.retrievePromises(): Begin");
        PromiseToPayData ptpData = accountService.retrievePromises(input.getOperatorId(),input.getCardNbr());
        LOG.debug("#### AccountController.retrievePromises(): End");  
        return ptpData;
    }
    
    @RequestMapping(value = "/cancelPaymentPromises", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void cancelPaymentPromises(@Valid @RequestBody CancelPromiseToPayInput input) throws Exception 
    {
        LOG.debug("#### AccountController.cancelPaymentPromises(): Begin");
         accountService.cancelPromises(input);
        LOG.debug("#### AccountController.cancelPaymentPromises(): End");  
       
    }

    @RequestMapping(value = "/getProvinceHoliday", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
	public List<ProvinceHoliday> getProvinceHoliday(@RequestBody ProvinceHoliday provHoliday) throws Exception 
	{
    	List<ProvinceHoliday> holidayList = accountService.getProvinceHoliday(provHoliday.getProvince(), provHoliday.getHoliday());
		return holidayList;
	}
    
    @RequestMapping(value = "/retrieveOneTimePayment", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
	public EPaymentTransaction retrieveOneTimePayments(@RequestBody PaymentInput input) throws Exception 
	{
    	EPaymentTransaction oneTimePayment = paymentService.retrieveOneTimePayment(input);
		return oneTimePayment;
	}
    @RequestMapping(value = "/retrieveRecurringPayment", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
	public EPaymentTransaction retrieveRecurringPayment(@RequestBody PaymentInput input) throws Exception 
	{
    	EPaymentTransaction oneTimePayment = paymentService.retrieveRecurringPayment(input);
		return oneTimePayment;
	}
    
    @RequestMapping(value = "/maintainRecurringPayment", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void maintainRecurringPayment(@RequestBody EPaymentTransaction epayment) throws Exception 
	{
    	paymentService.maintainRecurringPayment(epayment);
	}
    
    
    @RequestMapping(value = "/maintainOneTimePayment", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void maintainOneTimePayment(@RequestBody EPaymentTransaction epayment) throws Exception 
	{
    	paymentService.maintainOneTimePayment(epayment);
	}
    
    @RequestMapping(value = "/updateCustomDataField", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void updateCustomDataField(@RequestBody UpdateCDFValue cdfValue) throws Exception 
	{
    	accountService.updateCDF(cdfValue);
	}
    
    //Mappings Moved from Customer Service To Account Service: Begin
	/**
	 * To Refactor
	 * @param issueCardrequest
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/createCardholder", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void createCardholder(@RequestBody IssueCardRequest issueCardrequest) throws Exception{
		LOG.debug("#### CustomerServiceController.issueSuppcard(): Begin");
		LOG.debug("#### CustomerServiceController.issueSuppcard(): Input IssueCardrequest: " + issueCardrequest.toString());
		cardholderService.createCardHolder(issueCardrequest);
		LOG.debug("#### CustomerServiceController.issueSuppcard(): End");
	}
	
	/**
	 * To Refactor
	 * @param customerForUpdate
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateCardholder", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void updateCustomer(@RequestBody CustomerForUpdate customerForUpdate) throws Exception{
		Customer customer= prepareCustomer(customerForUpdate);
		LOG.debug("#### CustomerServiceController.updateCustomer(): Begin");
		LOG.debug("#### CustomerServiceController.updateCustomer(): Input Customer: " + customer.toString());
		customerUpdateService.updateCustomer(customer);
		accountService.removeAccountFromCache(customerForUpdate.getCardNumber());
		LOG.debug("#### CustomerServiceController.updateCustomer(): End");        
	}
	
	/**
	 * To Refactor
	 * @param input
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateEmail", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void updateEmail(@RequestBody EmailUpdateInput input) throws Exception{
		customerService.updateEmail(input);
		accountService.removeAccountFromCache(input.getAccountNbr());
	}
	
	/**
	 * To Refactor
	 * @param input
	 * @throws Exception
	 */
	@RequestMapping(value = "/retrieveEmailDates", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public CustomerEmailDates retrieveEmailDates(@RequestBody CustomerEmailInput input) throws Exception{
		return customerService.retrieveEmailDates(input);
		
	}
	
	/**
	 * To Refactor
	 * @param input
	 * @throws Exception
	 */
	@RequestMapping(value = "/generateCorrespondence", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void generateCorrespondence(@RequestBody CorrespondenceInput input) throws Exception{
		 customerService.generateCorrespondence(input);
	}
	
	/**
	 * To Refactor
	 * @param input
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/retrieveStatementProfile", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public StatementProfileOutput retrieveStatementProfile(@RequestBody EstatementInput input) throws Exception{
		return customerService.retrieveStatementProfile(input);
	}

	/**
	 * To Refactor
	 * @param input
	 * @throws Exception
	 */
	@RequestMapping(value = "/eStatementEnrollment", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void eStatementEnrollment(@RequestBody EstatementEnrollInput input) throws Exception{
		customerService.eStatementEnrollment(input);
		accountService.removeAccountFromCache(input.getAccountNumber());
	}
	
	/**
	 * To Refactor
	 * @param input
	 * @throws Exception
	 */
	@RequestMapping(value = "/eStatementDeenrollment", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void eStatementDeenrollment(@RequestBody EstatementInput input) throws Exception{
		customerService.eStatementDeenrollment(input);
		accountService.removeAccountFromCache(input.getAccountNumber());
	}
	
	/**
	 * To Refactor
	 * @param input
	 * @throws Exception
	 */
	@RequestMapping(value = "/storeEmailConsent", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void storeEmailConsent(@RequestBody EmailProfileInput input) throws Exception{
		customerService.storeEmailConsent(input);
	}
	@RequestMapping(value = "/retrieveEmailProfile", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public EmailProfile retrieveEmailProfile(@RequestBody EmailProfileInput input) throws Exception {
		
		return customerService.retrieveEmailProfile(input.getEmailAddress());
	}
	
	/**
	 * To Refactor
	 * @param input
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/retrieveEmploymentInfo", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public EmploymentInfo retrieveEmploymentInfo(@RequestBody EmploymentInfoInput input) throws Exception {
		
		return customerService.retrieveEmploymentInfo(input);
	}
	
	@RequestMapping(value = "/getAccountState", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public AccountStateOutput getAccountState(@RequestBody AccountStateInput input) throws MaxCVCAttemptsException, Exception
    {
        LOG.debug("getAccountState() entry");
        RegisteredCardState cardState = accountService.getAccountState(input.getCardNbr());
        AccountStateOutput stateOutput = new AccountStateOutput();
        stateOutput.setCardState(cardState);
        LOG.debug("getAccountState() exit");
        return stateOutput;
    }
	
	@RequestMapping(value = "/forceToQueue", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void forceToQueue(@RequestBody ForceToQueue ftq) throws Exception
    {
        LOG.debug("forceToQueue() entry");
        accountService.forceToQueue(ftq);
        LOG.debug("forceToQueue() exit");
    }
	
	@RequestMapping(value = "/getCustomerAccount", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public CustomerAccount getCustomerAccount(@RequestBody CustomerAccountInput input) throws Exception
    {
        LOG.debug("getCustomerAccount() entry");
        CustomerAccount custAcct = customerService.getCustomerAccount(input);
        LOG.debug("getCustomerAccount() exit");
        return custAcct;
    }
	
	/**
	 * @param cardHolderInput
	 * @throws Exception
	 */
	@RequestMapping(value = "/activateCard", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ActivateCardOuput activateCard(@RequestBody ActivateCardInput input) throws Exception{
		LOG.debug("#### AccountController.activateCards(): Begin");
		ActivateCardOuput out = new ActivateCardOuput();
		out.setCardNumber(input.getCardNumber());
		out.setCustomerId(input.getCustomerId());
		out = cardholderService.activateCard(input);
		
		LOG.debug("#### AccountController.activateCards(): End");  
		return out;
	}
	
	@RequestMapping(value = "/retrieveReissueStatus", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ReissueStatusOutput retrieveReissueStatus(@RequestBody AccountInput input) throws Exception{
		LOG.debug("#### AccountController.retrieveReissueStatus(): Begin");
		ReissueStatusOutput out = new ReissueStatusOutput();
		out = accountService.retrieveReissueStatus(null,input.getCardNbr());
		
		LOG.debug("#### AccountController.retrieveReissueStatus(): End");  
		return out;
	}
	
	private Customer prepareCustomer(CustomerForUpdate custUpdate)
	{
		Customer customer = new Customer();
		CustomerId customerId = new CustomerId();
		EmployerData empData=new EmployerData();
		PrimaryCardholder cardHolder= new PrimaryCardholder();		

		/*
		 * common to all packets
		 */
		cardHolder.setCardNbr(custUpdate.getCardNumber());
		customerId.setValue(Long.parseLong(custUpdate.getCustomerId()));
		customer.setCustomerId(customerId);
		cardHolder.setEmailAddress(custUpdate.getEmailId());

		if(custUpdate.getAddress() != null)
		{
			cardHolder.setAddress(custUpdate.getAddress());
		}

		MarketingOption marketingOption = new MarketingOption();
		if(custUpdate.getMarketingOption() != null)
		{
			marketingOption.seteMarketingOptInState(custUpdate.getMarketingOption().geteMarketingOptInState());
			marketingOption.seteStatementEnrollmentState(custUpdate.getMarketingOption().geteStatementEnrollmentState());
			marketingOption.seteOfferOptInState(custUpdate.getMarketingOption().geteOfferOptInState());
			cardHolder.setCustomerMarketingOption(marketingOption);
		}
		boolean employerUpdate=false;
		/** Empoyer Object Creation
		 */
		if(custUpdate.getEmployer() != null || custUpdate.getOccupation() != null || custUpdate.getAnnualIncome() > 0
				|| custUpdate.getEmployerCity() != null || custUpdate.getEmployerProv() != null)
		{
			employerUpdate=true;
		}
		empData.setEmployerName(custUpdate.getEmployer());
		empData.setJobTitle(custUpdate.getOccupation());
		empData.setMonthlyIncome(custUpdate.getAnnualIncome()/12);
		
		Address empAddress =  new Address();
		empAddress.setCity(custUpdate.getEmployerCity());
		empAddress.setProv(custUpdate.getEmployerProv());
		empData.setAddress(empAddress);
		customer.setEmployerData(empData);

		cardHolder.setPrefix(custUpdate.getPrefix());
		cardHolder.setSuffix(custUpdate.getSuffix());
		cardHolder.setName(custUpdate.getFullName());
		cardHolder.setEmbossedName(custUpdate.getEmbossedName());
		if(custUpdate.getTelephones()!=null)
		{
			for(TelephoneNumber tele:custUpdate.getTelephones())
			{
				if(tele != null && tele.getLocation() != null) 
				{
					if(tele.getLocation().equals(Location.ALT1))
					{
						cardHolder.setAltPhone1Ind(tele.getLocation().toString());
						cardHolder.setAltPhone1(tele.getNumber());
						cardHolder.setAltPhone1ConsentInd(getConsentIndiator(tele.getType()));
						continue;
					}
					if(tele.getLocation().equals(Location.ALT2))
					{
						cardHolder.setAltPhone2Ind(tele.getLocation().toString());
						cardHolder.setAltPhone2(tele.getNumber());
						cardHolder.setAltPhone2ConsentInd(getConsentIndiator(tele.getType()));
						continue;
					}
					if(tele.getLocation().equals(Location.HOME))
					{
						cardHolder.setHomePhoneInd(tele.getLocation().toString());
						cardHolder.setHomePhone(tele.getNumber());
						cardHolder.setHomePhoneConsentInd(getConsentIndiator(tele.getType()));
						continue;
					}
					if(tele.getLocation().equals(Location.WORK))
					{
						if(employerUpdate && tele.getNumber() != null)
						{
							empData.setBusinessPhone(tele.getNumber().toString());
							empData.setBusinessPhoneConsentInd(getConsentIndiator(tele.getType()));
						} 
						else 
						{
							cardHolder.setWorkPhoneInd(tele.getLocation().toString());
							cardHolder.setWorkPhone(tele.getNumber());
							cardHolder.setWorkPhoneConsentInd(getConsentIndiator(tele.getType()));
						}
						continue;
					}
				}
			}
		}
		customer.setCardholder(cardHolder);
		return customer;
	}
	
	/**
	 * To Refactor
	 * @param input
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateStatementProfile", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void updateStatementProfile(@RequestBody UpdateStatementProfileInput input) throws Exception 
	{
		
		// get the existing statementProfile
		EstatementInput estmtInput = new EstatementInput();
		estmtInput.setAccountNumber(input.getAccountNumber());
		StatementProfileOutput existStmtProfile = retrieveStatementProfile(estmtInput);

		CorrespondenceInput correspondenceInput = new CorrespondenceInput();
		correspondenceInput.setAccountNumber(input.getAccountNumber());
		// Estatement Enrollment scenario
		if(input.getElectronicStatementFlag())
		{
			if(existStmtProfile != null && existStmtProfile.getElectronicVendorId() != null && existStmtProfile.getElectronicVendorId().equals(VENDOR_EPOST)
					&& existStmtProfile.getElectronicStatementFlag()) 
			{
       	 		// If Enrolled for EPOST  deenroll first
				eStatementDeenrollment(estmtInput);
				
       	 		correspondenceInput.setCorrespondenceId(CONST_EPOST_DEENROLLMENT_ESTMT_ENROL_CORRESPONDENCE_ID);
       	 		correspondenceInput.setFormType(CONST_CORRESPONDENCE_LETTER_TYPE);
       	 		// correspondence call
       	 	    generateCorrespondence(correspondenceInput);
       	 	}
			EstatementEnrollInput  estatementEnrollInput = new EstatementEnrollInput();
       	    estatementEnrollInput.setAccountNumber(input.getAccountNumber());
       	    estatementEnrollInput.setElectronicStatementFlag(new Boolean(true));
       	    estatementEnrollInput.setElectronicHardCopyFlag(new Boolean(false));
       	    estatementEnrollInput.setElectronicVendorId(VENDOR_CTFS);
       	    estatementEnrollInput.setEmailAddress(input.getEmailAddress());
       	    // Check if already enrolled for estatements
       	    if(!existStmtProfile.getElectronicStatementFlag())
       	    {
       	    	eStatementEnrollment(estatementEnrollInput);
       	    }
		} 
		else 
		{ // Estatement de-Enrollment scenario
			if(existStmtProfile != null && ( existStmtProfile.getElectronicStatementFlag()
					|| existStmtProfile.getElectronicVendorId() != null && existStmtProfile.getElectronicVendorId().equals(VENDOR_EPOST)))
			{
				eStatementDeenrollment(estmtInput);
				
				// correspondence call
	   	 		if(existStmtProfile != null && existStmtProfile.getElectronicVendorId() != null && existStmtProfile.getElectronicVendorId().equals(VENDOR_EPOST)) 
	   	 		{
	       	 		correspondenceInput.setCorrespondenceId(CONST_EPOST_DEENROLLMENT_CORRESPONDENCE_ID);
	       	 	} 
	   	 		else 
	   	 		{
	       	 		correspondenceInput.setCorrespondenceId(CONST_ESTATEMENT_DEENROLLMENT_CORRESPONDENCE_ID);
	       	 	}
	       	    correspondenceInput.setFormType(CONST_CORRESPONDENCE_LETTER_TYPE);
	       	    generateCorrespondence(correspondenceInput);
			}
		}
		
		accountService.removeAccountFromCache(input.getAccountNumber());
	}

	private String getConsentIndiator(PhoneType type)
	{
		String result = null;
		if(type != null)
		{
			switch (type.getPhoneType()) 
			{
			case "Landline" :
				result = "L";
				break;
			case "Mobile":
				result = "E";
				break;
			case "Mobile-No Consent":
				result = "W";
				break;
			default:
				result = "";
				break;
			}
		}
		return result;
	}
    //Mappings Moved from Customer Service To Account Service: End
	
	@RequestMapping(value = "/retrieveCustomerPDAddress", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public CustomerAddressResponse retrieveCustomerPDAddress(@RequestBody CustomerAddressRequest input) throws Exception{
		return customerUpdateService.retrieveCustomerPDAddress(input);
		
	}
	@RequestMapping(value = "/maintainCustomerPDAddress", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public CustomerAddressResponse maintainCustomerPDAddress(@RequestBody CustomerAddressRequest input) throws Exception{
		return customerUpdateService.maintainCustomerPDAddress(input);
		
	}
	
	@RequestMapping(value = "/activateCPInsurance", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void activateCPInsurance(@RequestBody CPInsuranceBeanRequest input) throws Exception{
		insuranceService.enrolInsurance(input);
	}
	
	@RequestMapping(value = "/getGraceDueDate", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public GraceDueDateResponse getGraceDueDate(@RequestBody GraceDueDateRequest input) throws Exception{
		return accountService.getGraceDueDate(input);
	}
}
