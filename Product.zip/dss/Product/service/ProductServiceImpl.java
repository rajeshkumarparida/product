package com.product.service;

@Service("ProductService")
public class ProductServiceImpl implements ProductService
{

	 @Autowired
	    private ProductRepositary productRepositary;
	 
	    // Save operation
	    @Override
	    public Product saveProduct(Product product)
	    {
	        return productRepositary.save(product);
	    }
	 
	    // Read operation
	    @Override public List<Product> fetchProductList()
	    {
	        return (List<Product>)
	        		productRepositary.findAll();
	    }
	 
	    // Update operation
	    @Override
	    public Product updateProduct(Product product,
	                     Long productId)
	    {
	    	//Update
	    }
	 
	    // Delete operation
	    @Override
	    public void deleteProductById(Long productid)
	    {
	    	productRepositary.deleteById(productid);
	    }
	
}
